using UnityEngine;

public class TrackScript : MonoBehaviour
{
    public Animator animator;
}
